package com.krys.networklab.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.krys.networklab.data.CellularInfoReader
import com.krys.networklab.data.RadioSnapshot
import com.krys.networklab.data.SimulationSettings

private val Background = Color(0xFF09090B)
private val Panel = Color(0xFF171216)
private val PanelAlt = Color(0xFF21151A)
private val Crimson = Color(0xFFFF4057)
private val Muted = Color(0xFFB8A9AE)
private const val OOKLA_PACKAGE = "org.zwanoo.android.speedtest"

private enum class LabTab(val title: String) {
    SPEED("Speedtest"), RADIO("Cell stats"), SETTINGS("Overrides")
}

@Composable
fun NetworkLabApp() {
    val context = LocalContext.current
    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    var simulationEnabled by rememberSaveable { mutableStateOf(true) }
    var settings by remember { mutableStateOf(SimulationSettings()) }
    var radio by remember { mutableStateOf(RadioSnapshot()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        radio = CellularInfoReader(context).read()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Crimson,
        onPrimary = Color.White,
        secondary = Color(0xFFFF8797),
        background = Background,
        surface = Panel,
        onSurface = Color.White,
        onBackground = Color.White
    )) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF100D0F),
                    contentColor = Color.White,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    LabTab.entries.forEachIndexed { index, tab ->
                        val selected = tabIndex == index
                        NavigationBarItem(
                            selected = selected,
                            onClick = { tabIndex = index },
                            icon = {
                                when (tab) {
                                    LabTab.SPEED -> androidx.compose.material3.Icon(Icons.Filled.Speed, contentDescription = null)
                                    LabTab.RADIO -> androidx.compose.material3.Icon(Icons.Filled.CellTower, contentDescription = null)
                                    LabTab.SETTINGS -> androidx.compose.material3.Icon(Icons.Filled.Edit, contentDescription = null)
                                }
                            },
                            label = { Text(tab.title, fontSize = 11.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                Header()
                when (LabTab.entries[tabIndex]) {
                    LabTab.SPEED -> SpeedScreen(
                        settings = settings,
                        simulationEnabled = simulationEnabled,
                        onSimulationChange = { simulationEnabled = it },
                        onOpenOokla = {
                            val launchIntent = context.packageManager.getLaunchIntentForPackage(OOKLA_PACKAGE)
                            if (launchIntent != null) {
                                context.startActivity(launchIntent)
                            } else {
                                Toast.makeText(context, "Ookla Speedtest is not installed. Opening its Play Store listing.", Toast.LENGTH_LONG).show()
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$OOKLA_PACKAGE")))
                                }
                            }
                        }
                    )
                    LabTab.RADIO -> RadioScreen(
                        snapshot = radio,
                        onRefresh = {
                            val phoneGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
                            val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            if (phoneGranted && (fineGranted || coarseGranted)) {
                                radio = CellularInfoReader(context).read()
                            } else {
                                permissionLauncher.launch(arrayOf(
                                    Manifest.permission.READ_PHONE_STATE,
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                ))
                            }
                        }
                    )
                    LabTab.SETTINGS -> OverridesScreen(
                        settings = settings,
                        onSettingsChange = { settings = it },
                        simulationEnabled = simulationEnabled,
                        onSimulationChange = { simulationEnabled = it }
                    )
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth().background(Background).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("KRYS NETWORK LAB", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp, letterSpacing = 1.2.sp)
            Text("SPEEDTEST COMPANION  •  ANDROID", color = Crimson, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
        }
        Box(
            modifier = Modifier.size(38.dp).background(PanelAlt, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Icon(Icons.Filled.Wifi, contentDescription = null, tint = Crimson)
        }
    }
}

@Composable
private fun SpeedScreen(
    settings: SimulationSettings,
    simulationEnabled: Boolean,
    onSimulationChange: (Boolean) -> Unit,
    onOpenOokla: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("TEST CONSOLE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        StatusPill(if (simulationEnabled) "SIMULATION" else "REAL TEST")
                    }
                    Spacer(Modifier.height(15.dp))
                    if (simulationEnabled) {
                        Text(settings.downloadMbps.ifBlank { "—" }, color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Light)
                        Text("SIMULATED DOWNLOAD · Mbps", color = Crimson, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            Metric("UPLOAD", settings.uploadMbps, "Mbps")
                            Metric("IDLE PING", settings.idlePingMs, "ms")
                            Metric("JITTER", settings.jitterMs, "ms")
                        }
                    } else {
                        Text("No Ookla SDK connected", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(7.dp))
                        Text("The official Speedtest app can run a genuine test. This companion does not read or alter its results.", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(18.dp))
                    Divider(color = Color(0xFF38242B))
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Simulation overlay", color = Color.White, fontWeight = FontWeight.Medium)
                            Text("Local preview only; never changes a real test", color = Muted, fontSize = 10.sp)
                        }
                        Switch(checked = simulationEnabled, onCheckedChange = onSimulationChange)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PanelAlt), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("SIMULATED TEST PROFILE", color = Crimson, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    InfoLine("ISP", settings.ispName)
                    InfoLine("Server", settings.serverName)
                    InfoLine("Location", settings.serverLocation)
                    InfoLine("Access technology", settings.networkType)
                    InfoLine("Ping under download", "${settings.downloadPingMs} ms")
                    InfoLine("Ping under upload", "${settings.uploadPingMs} ms")
                    InfoLine("Packet loss", "${settings.packetLossPercent}%")
                    Text("Every value in this card is user-entered simulation data.", color = Muted, fontSize = 10.sp)
                }
            }
        }
        item {
            Button(
                onClick = onOpenOokla,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Crimson)
            ) {
                androidx.compose.material3.Icon(Icons.Filled.Speed, contentDescription = null)
                Spacer(Modifier.size(9.dp))
                Text("OPEN OOKLA SPEEDTEST", fontWeight = FontWeight.Bold)
            }
            Text("Opens the separately installed official app to run a real test. A licensed Ookla SDK is required for in-app test results.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp))
        }
    }
}

@Composable
private fun RadioScreen(snapshot: RadioSnapshot, onRefresh: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("LIVE RADIO DIAGNOSTICS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Android TelephonyManager", color = Muted, fontSize = 10.sp)
                        }
                        StatusPill(if (snapshot.available) "LIVE" else "PERMISSION")
                    }
                    Spacer(Modifier.height(4.dp))
                    InfoLine("Network technology", snapshot.networkType)
                    InfoLine("Registered radio", snapshot.registeredCellType)
                    InfoLine("Network operator", snapshot.networkOperator)
                    InfoLine("SIM operator", snapshot.simOperator)
                    InfoLine("Roaming", snapshot.roaming)
                    Text(snapshot.note, color = Muted, fontSize = 10.sp)
                    OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) {
                        Text("GRANT PERMISSIONS / REFRESH", color = Color.White)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PanelAlt), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("CELL IDENTITY", color = Crimson, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                    InfoLine("Cell ID / NCI", snapshot.cellId)
                    InfoLine("PCI", snapshot.physicalCellId)
                    InfoLine("TAC / LAC", snapshot.trackingArea)
                    InfoLine("EARFCN / NR-ARFCN", snapshot.channel)
                    InfoLine("MCC", snapshot.mcc)
                    InfoLine("MNC", snapshot.mnc)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("SIGNAL QUALITY", color = Crimson, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                    InfoLine("Signal power", snapshot.signalDbm)
                    InfoLine("RSRP / SS-RSRP", snapshot.rsrp)
                    InfoLine("RSRQ / SS-RSRQ", snapshot.rsrq)
                    InfoLine("SINR / RSSNR", snapshot.sinr)
                    InfoLine("CQI", snapshot.cqi)
                }
            }
        }
        item {
            Text("Some Android devices and carriers hide or omit specific fields. This app reads only what the device exposes; it does not estimate missing values.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp))
        }
    }
}

@Composable
private fun OverridesScreen(
    settings: SimulationSettings,
    onSettingsChange: (SimulationSettings) -> Unit,
    simulationEnabled: Boolean,
    onSimulationChange: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PanelAlt), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LOCAL RESULT OVERRIDES", color = Crimson, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, fontSize = 11.sp)
                    Text("Edit the preview values below. They are not sent to Ookla, your carrier, or a test server, and cannot change actual network performance.", color = Muted, fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Show simulation overlay", color = Color.White, fontSize = 13.sp)
                        Switch(checked = simulationEnabled, onCheckedChange = onSimulationChange)
                    }
                }
            }
        }
        item { SectionTitle("SPEED AND LATENCY") }
        item { SettingInput("Download speed (Mbps)", settings.downloadMbps) { onSettingsChange(settings.copy(downloadMbps = it)) } }
        item { SettingInput("Upload speed (Mbps)", settings.uploadMbps) { onSettingsChange(settings.copy(uploadMbps = it)) } }
        item { SettingInput("Idle ping (ms)", settings.idlePingMs) { onSettingsChange(settings.copy(idlePingMs = it)) } }
        item { SettingInput("Ping during download (ms)", settings.downloadPingMs) { onSettingsChange(settings.copy(downloadPingMs = it)) } }
        item { SettingInput("Ping during upload (ms)", settings.uploadPingMs) { onSettingsChange(settings.copy(uploadPingMs = it)) } }
        item { SettingInput("Jitter (ms)", settings.jitterMs) { onSettingsChange(settings.copy(jitterMs = it)) } }
        item { SettingInput("Packet loss (%)", settings.packetLossPercent) { onSettingsChange(settings.copy(packetLossPercent = it)) } }
        item { SectionTitle("SERVER AND PROVIDER") }
        item { SettingInput("Server name", settings.serverName) { onSettingsChange(settings.copy(serverName = it)) } }
        item { SettingInput("Server location", settings.serverLocation) { onSettingsChange(settings.copy(serverLocation = it)) } }
        item { SettingInput("ISP / network provider", settings.ispName) { onSettingsChange(settings.copy(ispName = it)) } }
        item { SettingInput("SIM operator", settings.simOperator) { onSettingsChange(settings.copy(simOperator = it)) } }
        item { SectionTitle("RADIO PREVIEW FIELDS") }
        item { SettingInput("Network type (e.g. LTE, NR, Wi-Fi)", settings.networkType) { onSettingsChange(settings.copy(networkType = it)) } }
        item { SettingInput("MCC-MNC", settings.mccMnc) { onSettingsChange(settings.copy(mccMnc = it)) } }
        item { SettingInput("Cell ID / NCI", settings.cellId) { onSettingsChange(settings.copy(cellId = it)) } }
        item { SettingInput("Band", settings.band) { onSettingsChange(settings.copy(band = it)) } }
        item { SettingInput("RSRP (dBm)", settings.rsrp) { onSettingsChange(settings.copy(rsrp = it)) } }
        item { SettingInput("RSRQ (dB)", settings.rsrq) { onSettingsChange(settings.copy(rsrq = it)) } }
        item { SettingInput("SINR (dB)", settings.sinr) { onSettingsChange(settings.copy(sinr = it)) } }
        item {
            OutlinedButton(
                onClick = { onSettingsChange(SimulationSettings()) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) { Text("RESET DEMO VALUES", color = Color.White) }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Crimson, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.padding(top = 5.dp, start = 3.dp))
}

@Composable
private fun SettingInput(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (
            label.contains("Mbps", true) || label.contains("ms", true) || label.contains("%", true) || label.contains("RSRP", true) || label.contains("RSRQ", true) || label.contains("SINR", true)
        ) KeyboardType.Decimal else KeyboardType.Text)
    )
}

@Composable
private fun Metric(label: String, value: String, unit: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.ifBlank { "—" }, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
        Text(unit, color = Muted, fontSize = 9.sp)
        Text(label, color = Crimson, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(value.ifBlank { "—" }, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StatusPill(text: String) {
    Box(
        modifier = Modifier.background(Color(0xFF3B111B), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(text, color = Color(0xFFFF8393), fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 0.8.sp)
    }
}
