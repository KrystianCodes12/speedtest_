package com.krys.networklab.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class CellularInfoReader(private val context: Context) {

    fun read(): RadioSnapshot {
        val hasPhonePermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
        val hasLocationPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPhonePermission || !hasLocationPermission) {
            return RadioSnapshot(
                note = "Grant Phone and Location permissions, then refresh. Android restricts some cell identity fields without them."
            )
        }

        return try {
            val manager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val networkType = networkTypeName(manager.dataNetworkType)
            val operator = manager.networkOperatorName.ifBlank { "Unavailable" }
            val simOperator = manager.simOperatorName.ifBlank { "Unavailable" }
            val roaming = if (manager.isNetworkRoaming) "Yes" else "No"
            val registered = manager.allCellInfo
                ?.firstOrNull { it.isRegistered }

            val base = RadioSnapshot(
                available = true,
                networkType = networkType,
                networkOperator = operator,
                simOperator = simOperator,
                roaming = roaming,
                note = if (registered == null) {
                    "Android did not return a registered cell. This can depend on the device, modem, carrier and Android permissions."
                } else {
                    "Live values read from Android TelephonyManager on this device."
                }
            )

            when (registered) {
                is CellInfoLte -> lteSnapshot(base, registered)
                is CellInfoWcdma -> wcdmaSnapshot(base, registered)
                is CellInfoGsm -> gsmSnapshot(base, registered)
                is CellInfoCdma -> cdmaSnapshot(base, registered)
                else -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && registered != null &&
                        registered.javaClass.name.endsWith("CellInfoNr")) {
                        nrSnapshot(base, registered)
                    } else base
                }
            }
        } catch (_: SecurityException) {
            RadioSnapshot(note = "Android denied access to cellular information. Check app permissions and device policy.")
        } catch (_: RuntimeException) {
            RadioSnapshot(note = "Cellular information is unavailable on this device right now.")
        }
    }

    private fun lteSnapshot(base: RadioSnapshot, info: CellInfoLte): RadioSnapshot {
        val id = info.cellIdentity
        val signal = info.cellSignalStrength
        val operator = id.operatorNumericParts()
        return base.copy(
            registeredCellType = "LTE",
            cellId = id.ci.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            physicalCellId = id.pci.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            trackingArea = id.tac.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            channel = id.earfcn.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            signalDbm = signal.dbm.takeIf { it != Int.MAX_VALUE }?.let { "$it dBm" } ?: "Unavailable",
            rsrp = signal.rsrp.takeIf { it != Int.MAX_VALUE }?.let { "$it dBm" } ?: "Unavailable",
            rsrq = signal.rsrq.takeIf { it != Int.MAX_VALUE }?.let { "$it dB" } ?: "Unavailable",
            sinr = signal.rssnr.takeIf { it != Int.MAX_VALUE }?.let { "$it dB" } ?: "Unavailable",
            cqi = signal.cqi.takeIf { it != Int.MAX_VALUE }?.toString() ?: "Unavailable",
            mcc = operator.first,
            mnc = operator.second
        )
    }

    private fun nrSnapshot(base: RadioSnapshot, info: CellInfo): RadioSnapshot {
        // CellInfoNr and its identity/signal APIs exist from Android 10 (API 29).
        return try {
            val identity = info.javaClass.getMethod("getCellIdentity").invoke(info)
            val signal = info.javaClass.getMethod("getCellSignalStrength").invoke(info)
            fun number(target: Any, method: String): String = runCatching {
                target.javaClass.getMethod(method).invoke(target).toString()
            }.getOrDefault("Unavailable")
            val nci = number(identity, "getNci")
            val pci = number(identity, "getPci")
            val tac = number(identity, "getTac")
            val nrarfcn = number(identity, "getNrarfcn")
            val ssRsrp = number(signal, "getSsRsrp")
            val ssRsrq = number(signal, "getSsRsrq")
            val ssSinr = number(signal, "getSsSinr")
            val dbm = number(signal, "getDbm")
            val mcc = number(identity, "getMccString")
            val mnc = number(identity, "getMncString")
            base.copy(
                registeredCellType = "5G NR",
                cellId = nci,
                physicalCellId = pci,
                trackingArea = tac,
                channel = nrarfcn,
                signalDbm = if (dbm == Int.MAX_VALUE.toString()) "Unavailable" else "$dbm dBm",
                rsrp = if (ssRsrp == Int.MAX_VALUE.toString()) "Unavailable" else "$ssRsrp dBm",
                rsrq = if (ssRsrq == Int.MAX_VALUE.toString()) "Unavailable" else "$ssRsrq dB",
                sinr = if (ssSinr == Int.MAX_VALUE.toString()) "Unavailable" else "$ssSinr dB",
                mcc = mcc,
                mnc = mnc
            )
        } catch (_: ReflectiveOperationException) {
            base.copy(registeredCellType = "5G NR", note = "5G cell detected, but this Android build does not expose all NR fields.")
        }
    }

    private fun wcdmaSnapshot(base: RadioSnapshot, info: CellInfoWcdma): RadioSnapshot {
        val id = info.cellIdentity
        val signal = info.cellSignalStrength
        return base.copy(
            registeredCellType = "WCDMA / UMTS",
            cellId = id.cid.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            physicalCellId = id.psc.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            trackingArea = id.lac.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            channel = id.uarfcn.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            signalDbm = signal.dbm.takeIf { it != Int.MAX_VALUE }?.let { "$it dBm" } ?: "Unavailable"
        )
    }

    private fun gsmSnapshot(base: RadioSnapshot, info: CellInfoGsm): RadioSnapshot {
        val id = info.cellIdentity
        val signal = info.cellSignalStrength
        return base.copy(
            registeredCellType = "GSM",
            cellId = id.cid.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            physicalCellId = id.bsic.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            trackingArea = id.lac.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            channel = id.arfcn.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            signalDbm = signal.dbm.takeIf { it != Int.MAX_VALUE }?.let { "$it dBm" } ?: "Unavailable"
        )
    }

    private fun cdmaSnapshot(base: RadioSnapshot, info: CellInfoCdma): RadioSnapshot {
        val id = info.cellIdentity
        val signal = info.cellSignalStrength
        return base.copy(
            registeredCellType = "CDMA",
            cellId = id.basestationId.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            trackingArea = id.networkId.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            channel = id.systemId.takeIf { it >= 0 }?.toString() ?: "Unavailable",
            signalDbm = signal.dbm.takeIf { it != Int.MAX_VALUE }?.let { "$it dBm" } ?: "Unavailable"
        )
    }

    private fun networkTypeName(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_GPRS,
        TelephonyManager.NETWORK_TYPE_EDGE,
        TelephonyManager.NETWORK_TYPE_GSM -> "2G"
        TelephonyManager.NETWORK_TYPE_UMTS,
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSPAP,
        TelephonyManager.NETWORK_TYPE_TD_SCDMA,
        TelephonyManager.NETWORK_TYPE_EVDO_0,
        TelephonyManager.NETWORK_TYPE_EVDO_A,
        TelephonyManager.NETWORK_TYPE_EVDO_B,
        TelephonyManager.NETWORK_TYPE_1xRTT -> "3G"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
        TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
        else -> "Unknown"
    }

    private fun android.telephony.CellIdentityLte.operatorNumericParts(): Pair<String, String> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return (mccString ?: "Unavailable") to (mncString ?: "Unavailable")
        }
        return "Unavailable" to "Unavailable"
    }
}
