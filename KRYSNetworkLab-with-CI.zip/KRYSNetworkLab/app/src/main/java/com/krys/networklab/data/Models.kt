package com.krys.networklab.data

data class SimulationSettings(
    val downloadMbps: String = "542.8",
    val uploadMbps: String = "60.2",
    val idlePingMs: String = "11",
    val downloadPingMs: String = "34",
    val uploadPingMs: String = "28",
    val jitterMs: String = "2.4",
    val packetLossPercent: String = "0.0",
    val serverName: String = "Bristol Speedtest Server",
    val serverLocation: String = "Bristol, United Kingdom",
    val ispName: String = "Example ISP",
    val networkType: String = "LTE",
    val simOperator: String = "Example Mobile",
    val mccMnc: String = "234-10",
    val cellId: String = "12345678",
    val band: String = "Band 20",
    val rsrp: String = "-91",
    val rsrq: String = "-10",
    val sinr: String = "14"
)

data class RadioSnapshot(
    val available: Boolean = false,
    val networkType: String = "Unknown",
    val networkOperator: String = "Unavailable",
    val simOperator: String = "Unavailable",
    val roaming: String = "Unknown",
    val registeredCellType: String = "Unavailable",
    val cellId: String = "Unavailable",
    val physicalCellId: String = "Unavailable",
    val trackingArea: String = "Unavailable",
    val channel: String = "Unavailable",
    val signalDbm: String = "Unavailable",
    val rsrp: String = "Unavailable",
    val rsrq: String = "Unavailable",
    val sinr: String = "Unavailable",
    val cqi: String = "Unavailable",
    val mcc: String = "Unavailable",
    val mnc: String = "Unavailable",
    val note: String = "Grant phone and location permissions to read cellular details."
)
