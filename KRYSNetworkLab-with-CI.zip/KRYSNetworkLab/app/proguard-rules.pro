# No custom keep rules are required for the starter project.
