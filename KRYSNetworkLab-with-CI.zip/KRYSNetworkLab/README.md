# KRYS Network Lab (Android)

A Kotlin + Jetpack Compose companion app for Android network diagnostics.

## What is included

- A dark crimson dashboard.
- A local simulation editor for download/upload, idle/download-loaded/upload-loaded ping, jitter, packet loss, ISP, server name/location, access technology, SIM operator, MCC/MNC, Cell ID/NCI, band, RSRP, RSRQ and SINR.
- Simulation values are shown only as a local preview and are not sent to Ookla, a carrier, or a test server.
- A **Open Ookla Speedtest** button that launches the separately installed official `org.zwanoo.android.speedtest` app. It does not modify that app or import its results.
- A Cell Stats tab that reads fields exposed by Android `TelephonyManager`, including LTE and (where Android/device support allows) 5G NR cell identifiers, channel numbers and signal metrics.

## Important Ookla integration note

This project does **not** patch or repackage the supplied Ookla APK. Ookla's terms restrict unauthorised modification and reverse engineering of its software. The app therefore leaves the official APK untouched.

Ookla offers a separately licensed Mobile SDK for integrating genuine Speedtest measurements into a developer's own Android app. The SDK is not included here. To show genuine Ookla measurements inside this app, obtain the appropriate SDK licence and SDK package from Ookla, then implement an adapter using the documentation supplied with that licensed SDK. The local simulation editor must remain separate from actual test results.

The current real-test button opens the official app. It is not an in-app SDK integration. No undocumented/private Ookla endpoints are used.

## Build requirements

- Android Studio (a current stable release)
- JDK 17
- Android SDK Platform 35
- Android device running Android 8.0 (API 26) or newer for the declared minimum SDK

## Build and install

1. Extract this project ZIP.
2. Open the `KRYSNetworkLab` folder in Android Studio.
3. Allow Gradle to sync and install any requested Android SDK components.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Select **app** and press **Run**.

To build a debug APK from a terminal with Gradle 8.10.2 or newer installed:

```bash
gradle assembleDebug
```

The output is normally:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Cellular permissions and limitations

The Cell Stats page asks for Phone and Location permissions because Android gates some cell identity and radio details behind those permissions. This project reads the fields locally and does not request GPS coordinates or upload cellular data. Android versions, device vendors, modems and carriers may hide or omit some fields; unavailable values are displayed as `Unavailable` rather than guessed. Some values may require Location Services to be enabled by Android even though this app does not store a location.

## Project structure

```text
KRYSNetworkLab/
├── app/
│   ├── src/main/
│   │   ├── java/com/krys/networklab/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/
│   │   │   │   ├── CellularInfoReader.kt
│   │   │   │   └── Models.kt
│   │   │   └── ui/
│   │   │       └── NetworkLabApp.kt
│   │   ├── res/values/styles.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```
