# Licensed Ookla SDK integration boundary

The app currently launches the separately installed official Speedtest app for a real run. It does not contain an Ookla SDK binary or private API client.

When a valid Ookla Mobile SDK licence and the vendor's Android integration documentation are available:

1. Add only the vendor-supplied SDK artifact to the project using the distribution and package instructions Ookla provides.
2. Create an `OoklaSpeedTestEngine` implementation that wraps the SDK's documented server-selection, test-start, progress and result callbacks.
3. Map only returned measurements into a new immutable `RealTestResult` model.
4. Display real measurements in a separate **REAL MEASUREMENTS** panel, with test timestamp and selected server.
5. Keep `SimulationSettings` and all manual overrides confined to the **SIMULATION** panel. Never write those values into the SDK result model or present them as measured results.
6. Request any extra location, phone-state or background permissions only when the licensed SDK feature actually requires them, and explain the reason in the UI.

Do not attempt to call undocumented Speedtest endpoints, alter the official APK, or modify results after a genuine test.
